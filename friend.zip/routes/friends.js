const mysql=require("mysql");
const express=require("express");
const friends=express();
var joi=require("joi");

const connection=mysql.createConnection({
    
    host: 'localhost',
    user: 'Pratik',
    password: 'project',
    database: 'Classwork'

});
var myData=[];
connection.connect();

 function validity(bodyContent)
 {
    const scema=
     {
         "Name":joi.string().required(),
        "Location":joi.string().required(),
         "Duretion":joi.string().required()
   };
    return joi.validate(bodyContent,scema);
 }
friends.post("/",function(request,response)
{
     let success=validity(request.body);
     if (success.error==null)


{ 
    let fName=request.body.Name;
    let fLocation=request.body.Location;
    let fDuretion=request.body.Duretion;

    let query=`insert into friends values('${fName}','${fLocation}','${fDuretion}')`;
    console.log(query);

    connection.query(query,function(err,result)
        {
        if (err==null)
         {
            
            response.contentType("application/json");
             response.send(JSON.stringify(result));
         }
        else
         {
            response.contentType("application/json");
             response.send(err)
        }
        });
}
else
 {
   response.contentType("application/json");
     response.send(success) 
 }
   
});

friends.put("/:Duretion",function(request,response)
{
    let fDuretion=request.params.Duretion;
    console.log(fDuretion);
    let fName=request.body.Name;
    let fLocation=request.body.Location;

    let query=`update friends set Name='${fName}',Location='${fLocation}' where Duretion='${fDuretion}'`;
    console.log(query);

    connection.query(query,function(err,result)
        {
        if (err==null)
         {
            
            response.contentType("application/json");
             response.send(JSON.stringify(result));
         }
        else
         {
            response.contentType("application/json");
             response.send(err)
        }
    });

    
});

friends.delete("/:Name",function(request,response)
{
    let fName=request.params.Name;
    let query=`delete from friends where Name='${fName}'`;
    console.log(query);

    connection.query(query,function(err,result)
        {
        if (err==null)
         {
            
            response.contentType("application/json");
             response.send(JSON.stringify(result));
         }
        else
         {
            response.contentType("application/json");
             response.send(err)
        }
    });

    
});




friends.get("/",function(request,response)
{
    connection.query("select * from friends",function(err,result)
    {
        if (err==null)
        {
            myData=result;
            response.contentType("application/json");
            response.send(JSON.stringify(myData));
        }
        else
        {
            response.contentType("application/json");
            response.send(err)
        }
    });
    
});

module.exports=friends;

